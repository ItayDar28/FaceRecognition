package hw5;

public interface MyInterface {
	
	public void insertDataFromDBFile(String objectName, int objectX, int objectY);
	
	public String[] firstSolution(int leftTopX, int leftTopY, int rightBottomX, int rightBottomY );

	public String[] secondSolution(int leftTopX, int leftTopY, int rightBottomX, int rightBottomY );

	
}

