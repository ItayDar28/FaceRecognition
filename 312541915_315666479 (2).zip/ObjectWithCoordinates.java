package hw5;

public interface ObjectWithCoordinates {
	public int getX();
	public int getY();
	public Object getData();
}

